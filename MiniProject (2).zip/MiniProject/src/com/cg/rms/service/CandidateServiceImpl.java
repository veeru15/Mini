package com.cg.rms.service;

import java.util.ArrayList;

public class CandidateServiceImpl implements CandidateService {

	@Override
	public ArrayList search(String qualification, String position,
			int experience) {
		return null;
	}

}
