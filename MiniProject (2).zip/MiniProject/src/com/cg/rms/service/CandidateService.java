package com.cg.rms.service;

import java.util.ArrayList;

public interface CandidateService {
		ArrayList search(String qualification,String position,int experience);
}
