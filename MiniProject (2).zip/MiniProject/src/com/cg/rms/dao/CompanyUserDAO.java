package com.cg.rms.dao;

import java.util.ArrayList;

import com.cg.rms.beans.CompanyMaster;
import com.cg.rms.beans.JobRequirements;
import com.cg.rms.beans.Candidate;
import com.cg.rms.exception.RecruitmentException;

public interface CompanyUserDAO {
    int registerCompany(CompanyMaster companyMaster) throws RecruitmentException;
    int postJobRequirement(JobRequirements jobRequirement) throws RecruitmentException;
    ArrayList<Candidate> searchCandidateQualification(String qualification) throws RecruitmentException;
    ArrayList<Candidate> searchCandidatePosition(String position) throws RecruitmentException;
    ArrayList<Candidate> searchCandidateYearOfExperience(int experience) throws RecruitmentException;

}
