package com.cg.rms.beans;

public class CompanyUser {
	private String userName;
	private String password;
	@Override
	public String toString() {
		return "CompanyUser [userName=" + userName + ", password=" + password
				+ "]";
	}
	public CompanyUser(String userName, String password) {
		super();
		this.userName = userName;
		this.password = password;
	}
	public CompanyUser() {
		super();
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
